import axios from "axios";

export const pokemonApi = axios.create();